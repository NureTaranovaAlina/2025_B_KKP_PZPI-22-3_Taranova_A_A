package com.example.mobile.domain.model

data class Nutrition(
    val _id: String,
    val current: Double,
    val target: Double,
)
