package com.example.mobile.domain.model

data class Role(
    val _id: String,
    val value: String,
    val description: String,
)
