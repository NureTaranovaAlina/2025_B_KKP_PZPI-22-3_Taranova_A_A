package com.example.mobile.domain.model

data class Activity(
    val _id: String,
    val name: String,
    val caloriesPerMin: Double
)
