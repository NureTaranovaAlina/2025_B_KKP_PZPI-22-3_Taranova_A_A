package com.example.mobile.data.dto.auth

data class LoginDto(
    val email: String,
    val username: String,
    val password: String,
)
