package com.example.mobile.data.dto.auth

data class PersonalizeResponse(
    val _id: String
)
